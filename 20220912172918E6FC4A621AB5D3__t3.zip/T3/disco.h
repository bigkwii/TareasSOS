void DiscoInit(void);
void DiscoDestroy(void);
char *dama(char *nom);
char *varon(char *nom);

