int vendo(int precio, char *vendedor, char *comprador);
int compro(char *comprador, char *vendedor);

