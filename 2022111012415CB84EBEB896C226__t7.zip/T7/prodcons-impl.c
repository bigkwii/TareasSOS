/* Implemente aqui el driver para /dev/prodcons */
