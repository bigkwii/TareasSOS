// El Makefile necesita que exista este archivo pero no va nada util aca

void emptyFunction() {
}

// Una unidad de compilacion no puede estar vacia
