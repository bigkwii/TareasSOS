void nFatalError( char *procname, char *format, ... );
void iniDisk(void);
void requestDisk(int track);
void releaseDisk(void);
